package com.borhan.amarot.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DutyDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDuty(duty: DutyRecord)

    // নির্দিষ্ট মাসের পুরো পুঞ্জীভূত (Total) ওভারটাইম ঘণ্টা বের করার কোয়েরি
    @Query("SELECT SUM(otHours) FROM duty_records WHERE monthYear = :monthYear")
    fun getTotalMonthlyOtHours(monthYear: String): Flow<Double?>

    // নির্দিষ্ট মাসের পুরো পুঞ্জীভূত রেগুলার ঘণ্টা বের করার কোয়েরি
    @Query("SELECT SUM(regularHours) FROM duty_records WHERE monthYear = :monthYear")
    fun getTotalMonthlyRegularHours(monthYear: String): Flow<Double?>

    // নির্দিষ্ট মাসের মোট অর্জিত ওভারটাইম টাকা (Wage)
    @Query("SELECT SUM(otWage) FROM duty_records WHERE monthYear = :monthYear")
    fun getTotalMonthlyOtWage(monthYear: String): Flow<Double?>

    // ওই মাসের সকল রেকর্ডের তালিকা
    @Query("SELECT * FROM duty_records WHERE monthYear = :monthYear ORDER BY date DESC")
    fun getDutiesForMonth(monthYear: String): Flow<List<DutyRecord>>
}
