package com.borhan.amarot.util

import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.Duration
import java.util.Locale

enum class ShiftType {
    DAY, NIGHT, HOLIDAY
}

data class CalculationResult(
    val totalHours: Double,
    val regularHours: Double,
    val otHours: Double
)

object OvertimeCalculator {

    private val timeFormatter = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH)

    /**
     * স্ট্রিং ইন/আউট সময় থেকে ডাইনামিক ওটি গণনা
     */
    fun calculate(
        startDateStr: String, // "2026-09-25"
        startTimeStr: String, // "07:53 AM"
        endDateStr: String,   // "2026-09-26" (রাত ১২টা পার হলে পরের দিন)
        endTimeStr: String,   // "12:11 AM"
        shiftType: ShiftType
    ): CalculationResult {

        val startLocalTime = LocalTime.parse(startTimeStr.uppercase(), timeFormatter)
        val endLocalTime = LocalTime.parse(endTimeStr.uppercase(), timeFormatter)

        val startDateTime = LocalDateTime.parse("${startDateStr}T$startLocalTime")
        val endDateTime = LocalDateTime.parse("${endDateStr}T$endLocalTime")

        // মোট ডিউটির মিনিট
        val totalMinutes = Duration.between(startDateTime, endDateTime).toMinutes().coerceAtLeast(0)
        val totalHours = totalMinutes / 60.0

        // Holiday Duty: all worked time is OT, except 13:00-14:00 lunch.
        // No late is calculated here. The caller can use totalHours/otHours.
        if (shiftType == ShiftType.HOLIDAY) {
            var lunchMinutes = 0L
            var lunchDate = startDateTime.toLocalDate()
            while (!lunchDate.atStartOfDay().isAfter(endDateTime)) {
                val lunchStart = lunchDate.atTime(13, 0)
                val lunchEnd = lunchDate.atTime(14, 0)
                val overlapStart = maxOf(startDateTime, lunchStart)
                val overlapEnd = minOf(endDateTime, lunchEnd)
                if (overlapEnd.isAfter(overlapStart)) {
                    lunchMinutes += Duration.between(overlapStart, overlapEnd).toMinutes()
                }
                lunchDate = lunchDate.plusDays(1)
            }
            val otMinutes = (totalMinutes - lunchMinutes).coerceAtLeast(0)
            val otHours = otMinutes / 60.0
            return CalculationResult(
                totalHours = String.format(Locale.ENGLISH, "%.2f", totalHours).toDouble(),
                regularHours = 0.0,
                otHours = String.format(Locale.ENGLISH, "%.2f", otHours).toDouble()
            )
        }

        // শিফট অনুযায়ী OT শুরু হওয়ার সময় কাট-অফ
        val otCutoffTime = if (shiftType == ShiftType.DAY) {
            LocalTime.of(17, 0) // ডে ডিউটি: বিকেল ৫:০০ টা
        } else {
            LocalTime.of(4, 0)  // নাইট ডিউটি: ভোর ৪:০০ টা
        }

        var otCutoffDateTime = startDateTime.toLocalDate().atTime(otCutoffTime)

        // নাইট শিফটের ক্ষেত্রে ভোর ৪:০০ টা পরের দিন পড়ে
        if (shiftType == ShiftType.NIGHT && otCutoffTime.isBefore(startLocalTime)) {
            otCutoffDateTime = otCutoffDateTime.plusDays(1)
        }

        // ওভারটাইম সময় বের করা
        val otMinutes = if (endDateTime.isAfter(otCutoffDateTime)) {
            val actualOtStart = if (startDateTime.isAfter(otCutoffDateTime)) startDateTime else otCutoffDateTime
            Duration.between(actualOtStart, endDateTime).toMinutes().coerceAtLeast(0)
        } else {
            0L
        }

        val otHours = otMinutes / 60.0
        val regularHours = (totalHours - otHours).coerceAtLeast(0.0)

        return CalculationResult(
            totalHours = String.format(Locale.ENGLISH, "%.2f", totalHours).toDouble(),
            regularHours = String.format(Locale.ENGLISH, "%.2f", regularHours).toDouble(),
            otHours = String.format(Locale.ENGLISH, "%.2f", otHours).toDouble()
        )
    }
}
