package com.borhan.amarot.data

import com.borhan.amarot.DutyDao
import com.borhan.amarot.DutyRecord
import kotlinx.coroutines.flow.Flow

class DutyRepository(private val dutyDao: DutyDao) {

    val allDutiesForMonth = { monthYear: String -> dutyDao.getDutiesForMonth(monthYear) }

    suspend fun insertDuty(duty: DutyRecord) {
        dutyDao.insertDuty(duty)
    }

    fun getTotalMonthlyOtHours(monthYear: String): Flow<Double?> {
        return dutyDao.getTotalMonthlyOtHours(monthYear)
    }

    fun getTotalMonthlyRegularHours(monthYear: String): Flow<Double?> {
        return dutyDao.getTotalMonthlyRegularHours(monthYear)
    }

    fun getTotalMonthlyOtWage(monthYear: String): Flow<Double?> {
        return dutyDao.getTotalMonthlyOtWage(monthYear)
    }
}
